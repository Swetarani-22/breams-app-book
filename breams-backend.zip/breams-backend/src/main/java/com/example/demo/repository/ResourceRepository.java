package com.example.demo.repository;

import org.springframework.data.jpa.repository.support.JpaRepositoryImplementation;

import com.example.demo.model.Resource;

public interface ResourceRepository extends JpaRepositoryImplementation<Resource, Integer> {
	Resource findByTitle(String title);
}
