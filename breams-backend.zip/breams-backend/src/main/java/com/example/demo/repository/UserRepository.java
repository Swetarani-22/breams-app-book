package com.example.demo.repository;

import org.springframework.data.jpa.repository.support.JpaRepositoryImplementation;

import com.example.demo.model.User;

public interface UserRepository extends JpaRepositoryImplementation<User, Integer>{
User findByName(String name);
	
//	User findById(Integer id);

	User findByEmail(String email);

}
