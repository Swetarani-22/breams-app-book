package com.example.demo.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;

import com.example.demo.model.Genre;
import com.example.demo.repository.GenreRepository;


@Service
public class GenreService {
	@Autowired
	private GenreRepository repository;
	
	public Optional<Genre> findOne(Integer id) {
		return repository.findById(id);
	}
	
	public List<Genre> findAll(Integer page) {
		return repository.findAll();
	}
	
//	public Page<Genre> findAll(int page){
//		return repository.findAll(new PageRequest(page,3));
//	}

	public Genre findByName(String name) {
		return repository.findByName(name);
	}

	public void save(Genre genre) {
		repository.save(genre);
	}

	public void delete(Integer id) {
		repository.deleteById(id);
	}

	public void delete(Genre genre) {
		repository.delete(genre);
	}

}
