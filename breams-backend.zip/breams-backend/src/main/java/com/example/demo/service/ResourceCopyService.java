package com.example.demo.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.model.ResourceCopy;
import com.example.demo.repository.ResourceCopyRepository;
@Service
public class ResourceCopyService {
	@Autowired
	private ResourceCopyRepository repository;
	
	public Optional<ResourceCopy> findOne(Integer id) {
		return repository.findById(id);
	}
	
	public ResourceCopy findByLocationCode(String locationCode) {
		return repository.findByLocationCode(locationCode);
	}
	
	public List<ResourceCopy> findAll() {
		return repository.findAll();
	}
	
//	public Page<ResourceCopy> findAll(int page){
//		return repository.findAll(new PageRequest(page,3));
//	}
//
//	public Long countByResource(Resource resource) {
//		return repository.countByResource(resource);
//	}

	public void save(ResourceCopy res_copy) {
		repository.save(res_copy);
	}

	public void delete(Integer id) {
		repository.deleteById(id);
	}

	public void delete(ResourceCopy copy) {
		repository.delete(copy);
	}
}
