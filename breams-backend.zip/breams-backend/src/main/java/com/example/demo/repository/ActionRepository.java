package com.example.demo.repository;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.support.JpaRepositoryImplementation;

import com.example.demo.model.Action;
import com.example.demo.model.User;

public interface ActionRepository extends JpaRepositoryImplementation<Action, Integer> {
	Action findByDateLoanInit(Date dateLoanInit);

	List<Action> findByUserId(Integer id);

	List<Action> findByUser(User user);
}
