package com.example.demo.repository;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.model.ResourceCopy;

public interface ResourceCopyRepository extends JpaRepository<ResourceCopy, Integer> {
ResourceCopy findByLocationCode(String locationCode);
	
	Long countByResource(Resource resource);

	List<ResourceCopy> findByResource(Resource resource);
}
