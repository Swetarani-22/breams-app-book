package com.example.demo.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.model.ResourceType;

public interface ResourceTypeRepository extends JpaRepository<ResourceType, Integer>{
	ResourceType findByName(String name);

	ResourceType findByNameLikeIgnoreCase(String type);
}
