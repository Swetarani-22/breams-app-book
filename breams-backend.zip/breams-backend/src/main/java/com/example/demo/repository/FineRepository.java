package com.example.demo.repository;

import org.springframework.data.jpa.repository.support.JpaRepositoryImplementation;

import com.example.demo.model.Fine;

public interface FineRepository extends JpaRepositoryImplementation<Fine,Integer> {

}
