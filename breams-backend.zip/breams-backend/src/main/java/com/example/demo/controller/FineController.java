package com.example.demo.controller;

import java.util.Optional;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.security.core.Authentication;

import com.example.demo.model.Fine;
import com.example.demo.service.FineService;
import com.example.demo.service.UserService;
import com.fasterxml.jackson.annotation.JsonView;


@RestController
@RequestMapping("/api/fines")
public class FineController {
	

	@Autowired
	private FineService fineService;
	@Autowired
	private UserService userService;

//	@JsonView(FineDetail.class)
	@RequestMapping(value = "", method = RequestMethod.GET)
	public ResponseEntity<Page<Fine>> getAllFine(Authentication authentication, HttpSession session,
			HttpServletRequest request, @RequestParam (required=false) Integer page) {

		session.setMaxInactiveInterval(-1);
		if(page==null) page=0;
//		if (request.isUserInRole("ADMIN")) {
//			Page<Fine> fines = fineService.findAll(page);
//			return new ResponseEntity<>(fines, HttpStatus.OK);
//		} else {
//			Page<Fine> fines = fineService.findByUser(userService.findByName(authentication.getName()), page);
//			return new ResponseEntity<>(fines, HttpStatus.OK);
		return null;
		}


//	@JsonView(FineDetail.class)
	@RequestMapping(value = "/{id}", method = RequestMethod.GET)
	public ResponseEntity<Fine> getFine(@PathVariable int id, Authentication authentication, HttpSession session,
			HttpServletRequest request) {

		session.setMaxInactiveInterval(-1);
		Optional<Fine> fine = fineService.findOne(id);
//		if (fine != null) {
//			if ((authentication.getName().contains(fine.getUser().getName())) || (request.isUserInRole("ADMIN")))
//				return new ResponseEntity<>(fine, HttpStatus.OK);
//			else
//				return new ResponseEntity<>(HttpStatus.UNAUTHORIZED);
//		} else {
//			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
//		}
		return null;
	}

	@RequestMapping(value = "/{id}", method = RequestMethod.DELETE)
	public ResponseEntity<Fine> deleteFine(@PathVariable Integer id) {
		return null;

//		Optional<Fine> fine = fineService.findOne(id);
//		if (fine != null) {
//			fineService.delete(fine);
//			return new ResponseEntity<>(fine, HttpStatus.OK);
//		} else {
//			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
//		}
	}

	@RequestMapping(value = "/{id}", method = RequestMethod.PUT)
	public ResponseEntity<Fine> putFine(@PathVariable Integer id, @RequestBody Fine fineUpdated) {

		Optional<Fine> fine = fineService.findOne(id);
//		if ((fine != null) && (fine.getId() == fineUpdated.getId())) {
//			return new ResponseEntity<>(HttpStatus.NOT_ACCEPTABLE);
//		} else {
//			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
//		}
		return null;
	}
}
