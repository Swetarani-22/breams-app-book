package com.example.demo.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.model.Fine;
import com.example.demo.repository.FineRepository;
@Service
public class FineService {
	@Autowired
	private FineRepository repository;
	
	public Optional<Fine> findOne(Integer id) {
		return repository.findById(id);
	}
	
	public List<Fine> findAll() {
		return repository.findAll();
	}
	
//	public Page<Fine> findAll(int page){
//		return repository.findAll(new PageRequest(page,3));
//	}
//
//	public List<Fine> findByUser(User user) {
//		return repository.findByUser(user);
//	}
//	
//	public Page<Fine> findByUser(User user, int page){
//		return repository.findByUser(user,new PageRequest(page,3));
//	}

	public void save(Fine fine) {
		repository.save(fine);
	}

	public void delete(Integer fine) {
		repository.deleteById(fine);
	}

	public void delete(Fine fine) {
		repository.delete(fine);
	}

}
