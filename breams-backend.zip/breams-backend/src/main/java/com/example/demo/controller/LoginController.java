package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.User;
import com.example.demo.service.UserService;

@RequestMapping("/api/auth")
@RestController
public class LoginController {

	  @Autowired
	private UserService userService;
	  

//	@Autowired
//	private UserComponent userComponent;

//@JsonView(UserDetail.class)
//	@RequestMapping(value = "/api/login")
//	public ResponseEntity<User> logIn() {
//		if (!userComponent.isLoggedUser()) {
//			log.info("Not user logged");
//			return new ResponseEntity<>(HttpStatus.UNAUTHORIZED);
//		} else {
//			User loggedUser = userComponent.getLoggedUser();
//			log.info("Logged as " + loggedUser.getName());
//			return new ResponseEntity<>(loggedUser, HttpStatus.OK);
//	}
//	
//
//	@RequestMapping("/api/logOut")
//	public ResponseEntity<Boolean> logOut(HttpSession session) {

//		if (!userComponent.isLoggedUser()) {
//			log.info("No user logged");
//			return new ResponseEntity<>(HttpStatus.UNAUTHORIZED);
//		} else {
//			session.invalidate();
//			log.info("Logged out");
//			return new ResponseEntity<>(true, HttpStatus.OK);
//		}
//	}

//	@RequestMapping(value = "/api/register", method = RequestMethod.POST))
//	public ResponseEntity<Boolean> register(HttpSession session, @RequestBody User user) {
////		if (userComponent.isLoggedUser()) {
////			return new ResponseEntity<>(HttpStatus.UNAUTHORIZED);
////		}
//		try {
//			User newUser = new User(user.getName(), user.getPasswordHash(), user.getDni(), user.getFirstName(),user.getLastName(), user.getEmail(), user.getTelephone(), "ROLE_USER", null);
//
//			userService.save(newUser);
//			return new ResponseEntity<>(true, HttpStatus.OK);
//		} catch (Exception e) {
//			return new ResponseEntity<>(HttpStatus.UNAUTHORIZED);
//		}
//	}


	 
	@PostMapping(value="/create")
	public User addUser(@RequestBody User user) {
	
//		  User user = new User(signUpRequest.getName(), signUpRequest.getPasswordHash(), signUpRequest.getDni(), signUpRequest.getFirstName(),signUpRequest.getLastName(), signUpRequest.getEmail(), signUpRequest.getTelephone(), null, null);
//	User newUser = new User(user.getName(), user.getPasswordHash(), user.getDni(), user.getFirstName(),user.getLastName(), user.getEmail(), user.getTelephone(), "ROLE_USER", null);
		  User newUser = new User(user.getName(), user.getPasswordHash(), user.getDni(), user.getFirstName(),
					user.getLastName(), user.getEmail(), user.getTelephone(), "ROLE_USER");
	
	
    
//    return userRepository.save(user);

//    return ResponseEntity.ok(new MessageResponse("User registered successfully!"));
//  
//
//		userService.save(newUser);
//		return new ResponseEntity<>(true, HttpStatus.OK);
//	} catch (Exception e) {
//		return new ResponseEntity<>(HttpStatus.UNAUTHORIZED);
//	}
		return userService.save(newUser);
//	}

}
}
