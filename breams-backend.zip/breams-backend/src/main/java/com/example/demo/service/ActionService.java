package com.example.demo.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.model.Action;
import com.example.demo.model.User;
import com.example.demo.repository.ActionRepository;
@Service
public class ActionService {
	@Autowired
	private ActionRepository repository;

	public Optional<Action> findOne(Integer id) {
		return repository.findById(id);
	}

	public List<Action> findAll() {
		return repository.findAll();
}

//	public Page<Action> findAll(int page) {
//		return repository.findAll(new PageRequest(page, 3, null));
//	}

	public List<Action> findByUser(User user) {
		return repository.findByUser(user);
	}

//	public Page<Action> findByUser(User user, int page) {
//		return repository.findByUser(user, new PageRequest(page, 3, null));
//	}
//
//	public Action findByDateLoanInit(Date dateLoanInit) {
//		return repository.findByDateLoanInit(dateLoanInit);
//	}
//
//	public Page<Action> findByDateLoanReturnAndUser(User user, int page, Date dateLoanReturn) {
//		return repository.findByDateLoanReturnAndUser(dateLoanReturn, user, new PageRequest(page, 3));
//	}
//
//	public Page<Action> findByUserAndDateLoanReturnNot(User user, int page, Date dateLoanReturn) {
//		return repository.findByUserAndDateLoanReturnNot(user, dateLoanReturn, new PageRequest(page, 3));
//	}

	public void save(Action action) {
		repository.save(action);
	}

	public void delete(Integer id) {
		repository.deleteById(id);
	}

	public void delete(Action action) {
		repository.delete(action);
	}
}
